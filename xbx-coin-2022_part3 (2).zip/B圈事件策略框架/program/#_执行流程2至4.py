"""
2022  B圈新版课程 | 邢不行
author: 邢不行
微信: xbx9585
"""
import os

os.system('python 2_事件生成.py')
os.system('python 3_合并event、K线数据.py')
os.system('python 4_事件策略回测.py')